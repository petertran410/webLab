export const content = ["./src/**/*.{html,js}"];
export const theme = {
  extend: {
    margin: {
      '-1px': '-1px'
    }
  },
};
export const plugins = [];
